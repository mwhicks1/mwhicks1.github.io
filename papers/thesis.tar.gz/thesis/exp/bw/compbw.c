#include <stdio.h>
#include <stdlib.h>
#include <gmp.h>

int main(void) {
  double t;
  unsigned long b;
  char buf[1024];
  mpf_t thisb;
  mpf_t thist;
  mpf_t totb;
  mpf_t tott;

  mpf_set_default_prec(256);
  mpf_init(thisb);
  mpf_init(totb);
  mpf_init(thist);
  mpf_init(tott);
  while(fgets(buf,sizeof(buf),stdin)) {
    b = atoi(buf);
    fgets(buf,sizeof(buf),stdin);
    t = atof(buf);
    mpf_set_ui(thisb,b);
    mpf_set_d(thist,t);
    mpf_add(totb,totb,thisb);
    mpf_add(tott,tott,thist);
  }
  mpf_set(thisb,totb);
  mpf_div(totb,totb,tott);
  mpf_set_ui(thist,8);
  mpf_mul(totb,totb,thist);
  mpf_set_ui(thist,1024 * 1024);
  mpf_div(totb,totb,thist);

  t = mpf_get_d(totb);
  printf("%f\n",mpf_get_d(totb));
}
