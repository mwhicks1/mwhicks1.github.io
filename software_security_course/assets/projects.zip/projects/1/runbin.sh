#!/bin/bash
while read -r line; do echo -e $line; done | ./wisdom-alt
